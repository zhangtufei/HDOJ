#include <iostream>
#include <string>
using namespace std;
int main()
{
	int n = 10;
	while (n--)
	{

	}
}